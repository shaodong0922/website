String.prototype.format= function() {
	if(arguments.length === 0) return this;
	var param = arguments[0], str= this;
	if(typeof(param) === 'object') {
		for(var key in param)
			str = str.replace(new RegExp("\\{" + key + "\\}", "g"), param[key] || "");
		return str;
	} else {
		for(var i = 0; i < arguments.length; i++)
			str = str.replace(new RegExp("\\{" + i + "\\}", "g"), arguments[i]);
		return str;
	}
}

Date.prototype.format = function (fmt) { 
	var o = {
		"M+": this.getMonth() + 1, //鏈堜唤
		"d+": this.getDate(), //鏃?
		"h+": this.getHours(), //灏忔椂
		"m+": this.getMinutes(), //鍒?
		"s+": this.getSeconds(), //绉?
		"q+": Math.floor((this.getMonth() + 3) / 3), //瀛ｅ害 
		"S": this.getMilliseconds() //姣
	};
	if (/(y+)/.test(fmt)){
		fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
	}
	for (var k in o){
		if (new RegExp("(" + k + ")").test(fmt)){
			fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
		}
	}	
	return fmt;
}

Function.prototype.getMultiLine = function() {  
	var lines = new String(this);  
	lines = lines.substring(lines.indexOf("/*") + 3, lines.lastIndexOf("*/"));  
	return lines;  
}

function GetRequest() {
    var url = location.search; //鑾峰彇url涓??"绗﹀悗鐨勫瓧涓?
    var theRequest = new Object();
    if (url.indexOf("?") != -1) {
        var str = url.substr(1);
        strs = str.split("&");
        for (var i = 0; i < strs.length; i++) {
            theRequest[strs[i].split("=")[0]] = decodeURIComponent(strs[i].split("=")[1]);
        }
    }
    return theRequest;
}

function object2UrlParamString(object){
	var ret = ""
	for (var key in object){
	  ret += '&'+'' + key + '=' + object[key]+'';
	}
	return ret
}


function ajax(url,data,method,successCallback){
	$.ajax({
		url: url,
		data:data,
		type:method,
		async: false,
		success:function(ret){
			if(successCallback){
				successCallback(ret)
			}
		}
	});
}


function get(url,successCallback){
	ajax(url,"","GET",successCallback)
}