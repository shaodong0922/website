
jQuery(".case01").slide({titCell:".case_bot ul",mainCell:".case01_m .case01_qie",autoPage:true,effect:"leftLoop",autoPlay:true,vis:4}); 
jQuery(".ys").slide({titCell:".ys_t ul li",mainCell:".ys_m",effect:"fade",autoPlay:false,delayTime:700});
jQuery(".news02").slide({mainCell:".wd_m .wd_qie",autoPlay:true,effect:"topMarquee",vis:3,interTime:30,trigger:"click"});
  jQuery(".jishu_r").slide({
			        mainCell: ".jishu_rm .jishu_qie",
			        autoPlay: true,
			        delayTime: 200,
			        vis: 3,
			        prevCell: ".jishu_lico",
			        nextCell: ".jishu_rico",
			        effect: "leftLoop"
			    });  


    $(".jishu_r").hide();
    $(".jishu_r").eq(0).show();
    $(".jishu01").mouseover(function(){
        if($(this).hasClass("jishu02")){
            $(".jishu_r").hide();
            $(".jishu_r").eq(1).show();
        }else if($(this).hasClass("jishu03")){
            $(".jishu_r").hide();
            $(".jishu_r").eq(2).show();
        }else{
            $(".jishu_r").hide();
            $(".jishu_r").eq(0).show();
        }
    });
	// index bottom js
    $(function () {

        var wow = new WOW({
            boxClass: 'wow',
            animateClass: 'animated',
            offset: 0,
            live: true
        });
        if (!(/msie [6|7|8|9]/i.test(navigator.userAgent))) {
            wow.init();
        };


        var width=$(window).width();

        if(width > 1024){
            window.addEvent('scroll',function () {
                if (window.scrollY <= 10){
                    $('header').removeClass('active');
                } else {
                    $('header').addClass('active');
                }
            });
        }else{
            $('header').addClass('active');
        }



        var banner_swiper = new Swiper('.banner .swiper-container',{
            speed:1000,
            loop:true,
            // autoplay:false,
            autoplay: {
                delay: 10000,
                stopOnLastSlide: false,
                disableOnInteraction: false,
            },
            pagination: {
                el: '.banner .swiper-pagination',
                // type: 'custom',
                clickable: true,
                renderBullet: function (index, className) {
                    return '<span class="' + className + '">' + ('0'+(index + 1)) + '</span>';
                },
            },
        });
var ProjectSlide01 = new Swiper('#ProjectA01', {
   autoplay: true,
    speed: 1200,
    parallax: true,
    prevButton:'.pj-prev-btn',
    nextButton:'.pj-next-btn',
    loop: true,
    loopAdditionalSlides: 3,
    slidesPerView: 5,
    centeredSlides: true,
    slidesPerGroup: 1,
     breakpoints: {
         1040: {
             slidesPerView: 3,
         },
       	768: {
             slidesPerView: 1,
         }
       }
   });
        $('.banner .sign').click(function () {
            if($(this).hasClass('active')){
                $(this).removeClass('active');
                banner_swiper.slideNext();
                banner_swiper.autoplay.start();
            }else{
                $(this).addClass('active');
                banner_swiper.autoplay.stop();
            }
        });

        if(width>768){
            $('.pardon-list .con ul li:first-child').addClass('active');
            $('.pardon-list .con ul li').each(function(){
                $(this).hoverDelay({
                    hoverDuring: 100,
                    outDuring: 100,
                    hoverEvent:function(){
                        $(this).addClass('active').siblings().removeClass('active');
                    }
                });
            });
        }


        var server_swiper = new Swiper('.server .swiper-container',{
            watchOverflow: true,
            speed:1000,
            // loop:true,
            // autoplay:false,
            spaceBetween : 26,
            slidesPerView: 4,
            // slidesPerGroup : 4,
            autoplay: {
                delay: 5000,
                stopOnLastSlide: false,
                disableOnInteraction: false,
            },
            pagination: {
                el: '.server .swiper-pagination',
                clickable: true,
            },
            breakpoints: {
                768:{
                    spaceBetween : 20,
                    slidesPerView: 2,
                }
            }
        });

        // 兼容ie10
        function dataset(element){
            var obj={};
            if(element.dataset){
                return element.dataset;
            }else{
                for(var i=0;i<element.attributes.length;i++){
                    var key=element.attributes[i].nodeName;
                    if(/^data-\w+$/.test(key)){//判断是否以data-开头的属性名
                        var value=element.attributes[i].nodeValue;//值
                        var keyName=key.match(/^data-(\w+)/)[1];//键名
                        obj[keyName]=value;//对象添加属性
                    }
                }
            }
            return obj;
        }

        var numSetAnimation = function (num, selector, timeOut, intNumS) {
            var max = num,
                o = selector;
            var intNum = intNumS;

            intNum = Number(intNum);
            var setTime = timeOut * intNum / num;
            var num_now = 0;
            // console.log(num_now);
            o.innerText = num_now.toFixed(0);

            var s = setInterval(function () {
                num_now += intNum;
                if (num_now >= max) {
                    clearInterval(s);
                    num_now = max
                }
                num_now = +num_now;
                o.innerText = num_now.toFixed(2) * 1;
            }, setTime);
        };
        var myFunction = function () {
            if (scrollT($('.scroll-num'))) {
                for (var i = 0; i < $(".n").length; i++) {
                    var itemNode = $(".n")[i];
                    // var num = itemNode.dataset.target;
                    var num=dataset(itemNode).target;
                    var growSpeed = Math.floor(num / 10);
                    numSetAnimation(num, itemNode, 1500, growSpeed);
                }
                window.removeEventListener('scroll', myFunction)
            }
        };
        window.addEvent('scroll', myFunction);

        //时间戳函数
        function timestampToTime(timestamp) {
            var date = new Date(timestamp);//时间戳为10位需*1000，时间戳为13位的话不需乘1000
            var Y = date.getFullYear() + '/';
            var M = (date.getMonth()+1 < 10 ? '0'+(date.getMonth()+1) : date.getMonth()+1) + '/';
            var D = (date.getDate() < 10 ? '0'+date.getDate() : date.getDate());
            var h = (date.getHours() < 10 ? '0'+date.getHours():date.getHours()) + ':';
            var m = (date.getMinutes() < 10 ? '0'+date.getMinutes():date.getMinutes()) + ':';
            var s = (date.getSeconds() < 10 ? '0'+date.getSeconds():date.getSeconds());
            return Y+M+D+' '+h+m+s;
        }

        var date=new Date();
        var datetime=date.getTime();
        $('.stock .time').text(timestampToTime(datetime));
        var stockData=hq_str_s_sh601003.split(",");
        if(Number(stockData[2])<0){
            $('.stock .text').addClass('active');
        }
        $('.stock .num').text(Number(stockData[1]));
        $('.add').text(Number(stockData[2]));
        $('.percent').text('('+Number(stockData[3])+'%)');


    })