window._bd_share_config={"common":{"bdSnsKey":{},"bdText":"","bdMini":"2","bdMiniList":false,"bdPic":"","bdStyle":"1","bdSize":"24"},"share":{}};with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='../bdimg.share.baidu.com/static/api/js/share6e53.js?v=89860593.js?cdnversion='+~(-new Date()/36e5)];
//_load
(function($,w){
	var winHei=$(w).height();
	var loadFn=function(){
		var $conLis=$('[_load]');
		$conLis.each(function(i,v){
			var scrollTop=$(w).scrollTop();
			var $v=$(v);
			if($conLis.filter('_load')==0) $(w).off('scroll.html');
			if( winHei+scrollTop > $v.offset().top){
				$v.addClass('active');
				$(this).removeAttr('_load');
			}
		})
	};
	$(w).on('scroll.z load',loadFn);
})(jQuery, window);

//requestAnimationFrame
(function() {
    var lastTime = 0;
    var vendors = ['webkit', 'moz'];
    for(var x = 0; x < vendors.length && !window.requestAnimationFrame; ++x) {
        window.requestAnimationFrame = window[vendors[x] + 'RequestAnimationFrame'];
        window.cancelAnimationFrame = window[vendors[x] + 'CancelAnimationFrame'] ||    // name has changed in Webkit
            window[vendors[x] + 'CancelRequestAnimationFrame'];
    }

    if (!window.requestAnimationFrame) {
        window.requestAnimationFrame = function(callback, element) {
            var currTime = new Date().getTime();
            var timeToCall = Math.max(0, 16.7 - (currTime - lastTime));
            var id = window.setTimeout(function() {
                callback(currTime + timeToCall);
            }, timeToCall);
            lastTime = currTime + timeToCall;
            return id;
        };
    }
    if (!window.cancelAnimationFrame) {
        window.cancelAnimationFrame = function(id) {
            clearTimeout(id);
        };
    }
})();





    $(function () {


        var width=$(window).width();


        if(width>1024){


            // $('header .con nav > ul > li').each(function(index){
            //     $(this).hoverDelay({
            //         hoverDuring: 300,
            //         outDuring: 300,
            //         hoverEvent:function(){
            //             $('.header-search').slideUp();
            //             $('.search').removeClass('active');
            //             if(index == 0){
            //                 $('header .header-list .big').slideUp();
            //             }else{
            //                 $('header .header-list .big').slideUp("fast").eq(index-1).slideDown("slow");
            //             }

            //         }
            //     });
            // });

            $('header').mouseleave(function () {
                $('header .header-list .big').slideUp();
                $('.header-search').slideUp();
                $('.search').removeClass('active');
            });

            $('.lang').mouseenter(function () {
                $('header .header-list .big').slideUp();
            });

            $('.search').click(function () {
                $('header .header-list .big').slideUp();
                if($(this).hasClass('active')){
                    $('.header-search').slideUp();
                    $(this).removeClass('active');
                }else{
                    $('.header-search').slideDown();
                    $(this).addClass('active');
                }

            });



        }else{

            $('header .con nav > ul > li').click(function () {
                $(this).find('ul').slideToggle();
                $(this).siblings().find('ul').slideUp();
                $(this).toggleClass('active');
                $(this).siblings().removeClass('active');
            });

            $('.nav-button').click(function () {
                    if($(this).hasClass('active')){
                    $(this).removeClass('active');
                    $('header .con nav').slideUp();
                    $('header .con nav> ul > li ul').slideUp();
                    $('header .con nav> ul > li').removeClass('active');
                }else{
                    $(this).addClass('active');
                    $('header .con nav').slideDown();
                }

            });


            $('.search').click(function () {
                $('header .header-list .big').slideUp();
                $('.nav-button').removeClass('active');
                $('header .con nav').slideUp();
                $('header .con nav> ul > li ul').slideUp();
                $('header .con nav> ul > li').removeClass('active');
                if($(this).hasClass('active')){
                    $('.header-search').slideUp();
                    $(this).removeClass('active');
                }else{
                    $('.header-search').slideDown();
                    $(this).addClass('active');
                }

            });


            $(document).mouseup(function (e) {
                var con = $('.nav-button');   // 设置目标区域
                var con1= $('.search');
                var con2=$('.header-search');
                var con3=$('header nav');
                if (!con.is(e.target) && con.has(e.target).length === 0 && !con1.is(e.target) && con1.has(e.target).length === 0 && !con2.is(e.target) && con2.has(e.target).length === 0 && !con3.is(e.target) && con3.has(e.target).length === 0) {
                    $('.nav-button').removeClass('active');
                    $('header .con nav').slideUp();
                    $('header .con nav> ul > li ul').slideUp();
                    $('header .con nav> ul > li').removeClass('active');
                    $('.header-search').slideUp();
                    $('.search').removeClass('active');
                }
            });




        }





        function isIE() {
            if (!!window.ActiveXObject || "ActiveXObject" in window) {
                $('body').attr('id','ie');
                return true;
            } else {
                return false;
            }
        }

        isIE();





        // 搜索
        function isEmpty(value){
            return value != "" && value != null && $.trim(value) != "" && value != undefined;
        }

        $(".search-right span").click(function(e){
            e.preventDefault();
            var keyword =$(".search-box input").val();
            if(isEmpty(keyword)){
                var url = 'search.html';
                url = url +"?keyword="+encodeURIComponent(encodeURIComponent(keyword));
                window.open(url);
                $(".search-box input").val('')
            }
        });
        document.onkeyup = function (e) {
            if (window.event) e = window.event;
            var code = e.charCode || e.keyCode;
            if (code == 13 && $(".search-box input").val()) {
                var keyword =$(".search-box input").val();
                if(isEmpty(keyword)){
                    var url = 'search.html';
                    url = url +"?keyword="+encodeURIComponent(encodeURIComponent(keyword));
                    window.open(url);
                    $(".search-box input").val('')
                }
            }
        };
        /*--过滤危险字符--*/
        $('input[type=text],textarea,input[type=password]').keyup(function () {
            var val = $(this).val().toLocaleLowerCase();
            var otherKey = ")|(|payload| and | exec | count | chr | mid | master | or | truncate | char | declare | join |<|>|*|/*|*/|;|\\u|insert|select|delete|update|create|drop|script|javascript|alert";
            var goon = true;
            for (var i = 0; i < otherKey.split('|').length ; i++) {
                if (goon) {
                    if (val.indexOf(otherKey.split('|')[i]) != -1) {
                        alert('不能包含危险字符!');
                        $(this).val('');
                        goon = false;
                        return;
                    }
                }
            }
        });




    });


