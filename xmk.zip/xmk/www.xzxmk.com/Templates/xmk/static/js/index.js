
/*$(function(){

    $('#fullpage').fullpage({
        verticalCentered: true,
        anchors: ['index', 'theme', 'tour', 'center', 'news'],
        navigationTooltips: ['1', '2', '3', '4', '5'],
        // scrollOverflow: true,
        keyboardScrolling: true,
        slidesNavigation: true,
        navigation: false,
        sectionSelector: '.section',
        // slideSelector: '.slide',
        controlArrows: false,
    });

    function con1SwiperInit() {

        var mySwiper = new Swiper ('.swiper-container.con1', {
            loop: true,
            pagination: '.con1 .swiper-pagination',
            nextButton: '.con1 .swiper-button-next',
            prevButton: '.con1 .swiper-button-prev',

            slidesPerView : 1,
        });
        return mySwiper;
    }

    var bannerSwiper = con1SwiperInit();

})*/
