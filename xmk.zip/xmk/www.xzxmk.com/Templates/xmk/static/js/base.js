$(function(){
    if(!placeholderSupport()){
        $('[placeholder]').focus(function() {
            var input = $(this);
            if (input.val() == input.attr('placeholder')) {
                input.val('');
                input.removeClass('placeholder');
            }
        }).blur(function() {
            var input = $(this);
            if (input.val() == '' || input.val() == input.attr('placeholder')) {
                input.addClass('placeholder');
                input.val(input.attr('placeholder'));
            }
        }).blur();
    };
    if(!IsPC()){$('body').addClass('touch_body')}

    if(isIE()){$('html').addClass('isIe');}

    var url_location = window.location.pathname;
    var arr = [];
    arr = url_location.split('index.html');
})

function placeholderSupport() {
    return 'placeholder' in document.createElement('input');
}
function scrollT($Dom){
    if($Dom.offset()){
      if($(window).scrollTop()+$(window).height()>=$Dom.offset().top+200){
          return true;
      }
    }
}
function mainBgResize1($img, width, height, W_b, H_b) {
    var sw = width,
        sh = width / W_b * H_b
    if (sh < height) {
        sh = height;
        sw = height / H_b * W_b
    }
    $img.css({height:sh,width:sw, marginTop: -(sh - height) / 2, marginLeft: -(sw - width) / 2, 'visibility': 'visible' });

}
function isFirefox(){
    if (navigator.userAgent.indexOf("Firefox") > -1) 
    return true;
    else
    return false;
}
function isIE() {
    if (!!window.ActiveXObject || "ActiveXObject" in window)
    return true;
    else
    return false;
}
function IsPC() { 
   var userAgentInfo = navigator.userAgent; 
   var Agents = new Array("Android", "iPhone", "SymbianOS", "Windows Phone", "iPad", "iPod"); 
   var flag = true; 
   for (var v = 0; v < Agents.length; v++) { 
       if (userAgentInfo.indexOf(Agents[v]) > 0) { flag = false; break; } 
   } 
   return flag; 
}  
function addEvent(eve,callback){
  if (window.attachEvent){
      window.attachEvent("on"+eve,callback); 
  }else if(window.addEventListener) { 
      window.addEventListener(eve,callback,false);   
  }
}
addEvent('load', function(){
    window.onorientationchange = orientationChange;
});
function orientationChange() {
	switch(window.orientation){
		case 0:
		window.location.reload();break;	
		case -90:
		window.location.reload();break;	
		case 90:
		window.location.reload();break;	
		case 180:
		window.location.reload();break;	
	}
};
function getBrowserVersion(){
  var hc = $('html').attr('class');
  if(hc){
    var ieVersion = hc && hc.split(' ')[1];
    if(ieVersion){
      $('.browserupgrade>strong').text(ieVersion.toUpperCase());
    }
  }
}
getBrowserVersion();
$.fn.hoverDelay = function(options){
    var defaults = {
        hoverDuring: 200,
        outDuring: 200,
        hoverEvent: function(){
            $.noop();
        },
        outEvent: function(){
            $.noop();    
        }
    };
    var sets = $.extend(defaults,options || {});
    var hoverTimer, outTimer, that = this;
    return $(this).each(function(){
        $(this).on('mouseenter',function(){
            clearTimeout(outTimer);
            hoverTimer = setTimeout(function(){sets.hoverEvent.apply(that)}, sets.hoverDuring);
        });
        $(this).on('mouseleave',function(){
            clearTimeout(hoverTimer);
            outTimer = setTimeout(function(){sets.outEvent.apply(that)}, sets.outDuring);
        });
    });
}

