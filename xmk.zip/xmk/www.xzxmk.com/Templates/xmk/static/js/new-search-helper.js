var requesturl = "http://8.135.107.110:6001/action/newSearch"

$(document).ready(function() {	
	$('.select-year ul li').click(function(){
		var newType = $(".new-type").text()
		var year = $(this).text()
		if(year == '鍏ㄩ儴'){
			window.location.href=window.newSearchBoxParam.initPage;
			return
		}
		var param = {
			newType:parseInt(newType),
			year:year
		}
		window.year = year
		window.keyword = null
		get(requesturl+"?"+object2UrlParamString(param),function(ret){
			handleResponse(ret)
		})
	})	
	$('.new-search-btn').click(function(){
		var newType = $(".new-type").text()
		var keyword = $(".new-search-btn-input").val()
		var curYear = $(".current-year").text()
		
		if(!keyword || keyword.trim().length <= 0){
			alert("")
			return
		}
		
		var param = {
			newType:parseInt(newType),
			keyword:keyword
		}
		
		if(curYear && curYear != '鍏ㄩ儴'){
			param.year = curYear
			window.year = curYear
		}else{
			window.year = null
		}
		
		window.keyword = keyword
		get(requesturl+"?"+object2UrlParamString(param),function(ret){
			handleResponse(ret)
		})
	})
});



function jump(pageNum){
	var p ={
		newType:parseInt($(".new-type").text()),
		currentPage:pageNum
	}
	if(window.keyword){
		p.keyword = window.keyword
	}
	if(window.year){
		p.year = window.year
	}
	get(requesturl+"?"+object2UrlParamString(p),function(ret){
		handleResponse(ret)
	})
}



function handleResponse(ret){
	if(ret.data){
		$('.crt-page').text(ret.data.currentPage)
		$('.page-count').text(ret.data.totalPage)
		$(".page-list").show()
		var searchResultList = $(".search-result-list") //鎼滅储缁撴灉鏄剧ず鍖哄煙
		var searchResultPageList = $("#page-num-list") //鎼滅储缁撴灉鍒嗛〉淇℃伅鏄剧ず鍖哄煙
		
		$("#pre-new-btn").unbind("click")
		$("#pre-new-btn").removeAttr("href");
		$('#pre-new-btn').click(function(){
			jump(ret.data.currentPage <= 1 ?  1 : ret.data.currentPage - 1)
		})
		$("#next-new-btn").unbind("click")
		$("#next-new-btn").removeAttr("href");
		$('#next-new-btn').click(function(){
			jump(ret.data.currentPage >= ret.data.totalPage  ? ret.data.totalPage : ret.data.currentPage + 1)
		})
		
		var searchResultListHtml = "";
		var searchResultPageListHtml = "";
		
		
		var PAGE_OFFSET = 4
		var start = ret.data.currentPage - PAGE_OFFSET;
		start = start < 1 ? 1 : start;
		var end = ret.data.currentPage + PAGE_OFFSET;
		end = end > ret.data.totalPage ? ret.data.totalPage : end;
		for (var j = start; j <= end; j++) {
			if(j == ret.data.currentPage){
				searchResultPageListHtml += '<li class="page-num-block page-num active"> <a class="page-num-block-a" onclick="jump('+j+');">'+j+'</a></li>';
			}else{
				searchResultPageListHtml += '<li class="page-num-block page-num"><a class="page-num-block-a" onclick="jump('+j+');">'+j+'</a></li>';
			}
		}
		for (var i = 0; i < ret.data.objects.length; i++) {
			if(ret.data.objects[i].publishTime){
				ret.data.objects[i].publishTime = new Date(ret.data.objects[i].publishTime).format("yyyy-MM-dd")
			}
			if(ret.data.objects[i].time){
				ret.data.objects[i].time = new Date(ret.data.objects[i].time).format("yyyy-MM-dd")
			}
			searchResultListHtml += window.newSearchBoxParam.template.getMultiLine().format(ret.data.objects[i])
		}
	}else{
		if(ret.msg){
			alert(ret.msg)
		}
	}
	
	
	searchResultList.html(searchResultListHtml==""?"<div style='display: flex; justify-content: center; align-items: center;'><h2>娌℃湁鍖归厤鐨勭粨鏋滐紒</h2></div>" : searchResultListHtml)
	searchResultPageList.html(searchResultPageListHtml)
	if(searchResultListHtml==""){
		$(".page-list").hide()
	}





    $('.video-list>ul>li').unbind("click")
    $('.video-list>ul>li').on('click',function(e){
        var videoUrl=$(this).attr('video-source');
        if(videoUrl){
            $('#videoPopup video').attr('src',videoUrl);
            $('#videoPopup').show();
        }
    });
	
	
	$('.employ .con .employ-body .box .box-top').click(function () {
	   if($(this).parent().hasClass('active')){
		   $(this).parent().removeClass('active');
		   $(this).parent().find('.box-bottom').slideUp();
	   }else{
		   $(this).parent().addClass('active').siblings().removeClass('active');
		   $(this).parent().siblings().find('.box-bottom').slideUp();
		   $(this).parent().find('.box-bottom').slideDown();
	   }
	});


}


